<?php
  $connect = mysqli_connect('localhost', 'root', '', 'webar');


  $string = 'SELECT * FROM `Members`';
  $query = mysqli_query($connect, $string);
   if (mysqli_num_rows($query)>0) {
      while($row = mysqli_fetch_assoc($query)){
         echo 'id : '.$row['ID'].'<br/>';
         echo 'id : '.$row['PW'].'<br/>';
         echo 'id : '.$row['name'].'<br/>';
         echo 'id : '.$row['age'].'<br/>';
         echo 'id : '.$row['email'].'<br/>';
         echo 'id : '.$row['telephone'].'<br/>';

      }
      
   } else{
      echo "데이터가 없습니다.";
   }