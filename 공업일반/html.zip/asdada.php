<?php
$connect = mysqli_connect('localhost','root','webar');

$query = 'INSERT into 'Members' (email,password,name,gender) value()'
?>