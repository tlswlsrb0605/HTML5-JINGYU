<?php 
    if($a == 10){
    	echo 'a는 10이다';
    } else if ($a == 5){
    	echo 'a는 5다';
    } else {
    	echo 'a는 10이 아니다';
    }
    for($i = 0; $i < 5; $i++){
    	echo $i;
    }

    ?>
