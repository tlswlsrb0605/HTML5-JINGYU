<?php
$connect = mysqli_connect('localhost','root','','webar');
mysqli_set_charset($connect,'utf8');

var_dump($_POST);
$email = $_POST['email'];
$password = $_POST['password'];
//SELECT * FORM 'Members' 멤버에 있는 내용을 불러온다.
//SELECT * FORM 'Members' WHERE 'A'='a' AND 'B'='b'
$query = sprintf("SELECT * FROM `members` WHERE `email`='%s' AND `password`='%s'",$email,$password);
$query = mysqli_query($connect, $query);

if(mysqli_num_rows($query)>0) {
	while ($row = mysqli_fetch_assoc($query)){
		// $_POST, $_GET
		$_SESSION['name'] = $row['name'];
		$_SESSION['email'] = $row['email'];
		$_SESSION['nick'] = $row['nick'];
		$_SESSION['gender'] = $row['gender'];

		echo '<script>alert("로그인 되었습니다");location.href="./index.html";</script>';
	}
} else{
    echo '로그인 실패';
  }