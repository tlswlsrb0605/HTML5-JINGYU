<?php
    session_start();
    echo $_SESSION['email'] . '님의 이름은' . $_SESSION['name'] . '입니다.';
   